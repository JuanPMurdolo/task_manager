import pytest
from datetime import datetime, timedelta
from app.schemas.task import TaskCreate, TaskUpdate
from app.repositories.task import TaskRepository

@pytest.mark.asyncio
async def test_create_task_in_db(db_session, create_test_user):
    user = await create_test_user("creator", "123")
    repo = TaskRepository(db_session)
    task_data = TaskCreate(
        title="Task title",
        description="Test description",
        status="todo",
        priority=1,
        due_date=datetime.utcnow() + timedelta(days=1),
        assigned_to=None
    )
    task = await repo.create_task_in_db(task_data, user.id)
    assert task.title == "Task title"

@pytest.mark.asyncio
async def test_update_task_in_db_found_and_not_found(db_session, create_test_user):
    user = await create_test_user("updater", "123")
    repo = TaskRepository(db_session)
    task_data = TaskCreate(
        title="Task to update",
        description="Desc",
        status="todo",
        priority=2,
        due_date=datetime.utcnow(),
        assigned_to=None
    )
    task = await repo.create_task_in_db(task_data, user.id)
    update = TaskUpdate(title="Updated")
    updated = await repo.update_task_in_db(task.id, update, user.id)
    assert updated.title == "Updated"
    not_found = await repo.update_task_in_db(9999, update, user.id)
    assert not_found is None
