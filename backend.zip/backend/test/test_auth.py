import pytest
from httpx import AsyncClient
from app.schemas.auth import UserCreate

@pytest.mark.asyncio
async def test_register_user_success(test_client: AsyncClient):
    response = await test_client.post("/auth/register", json={
        "username": "testuser",
        "email": "testuser@example.com",
        "full_name": "Test User",
        "password": "test123"
    })
    assert response.status_code == 200
    assert response.json()["username"] == "testuser"

@pytest.mark.asyncio
async def test_authenticate_user_invalid(test_client: AsyncClient):
    response = await test_client.post("/auth/login", data={
        "username": "invaliduser",
        "password": "wrongpass"
    })
    assert response.status_code == 401
